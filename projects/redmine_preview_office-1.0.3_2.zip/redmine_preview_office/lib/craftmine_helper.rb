module Craftmine
  module Helper
    def self.name
      " (Redmine 4.*修复版)".html_safe
    end

    def self.version
      "_2"
    end

    def self.description
      " <a href=https://www.redmineplugins.cn>(由 www.redmineplugins.cn 提供下载)</a>".html_safe
    end
  end 
end

Redmine::Plugin.find(:redmine_preview_office).instance_eval do
  @name = @name.html_safe + Craftmine::Helper::name
  @version = @version + Craftmine::Helper::version
  @description = @description.html_safe + Craftmine::Helper::description
end
# 
